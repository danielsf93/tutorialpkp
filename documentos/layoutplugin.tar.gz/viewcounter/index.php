<?php
require_once('viewcounter.php');
return new viewcounter();
